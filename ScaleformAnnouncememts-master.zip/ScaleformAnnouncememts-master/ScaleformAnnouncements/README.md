# Scaleform Announcements
This resource is pretty simple, it allows you to do clean announcements which display for a set amount of time.

Usage:
`/announce [type] [time] [font (if type == 2)] [msg]`
type can be either 1 or 2. Example:
https://images.illusivetea.me/0973j3.mp4
